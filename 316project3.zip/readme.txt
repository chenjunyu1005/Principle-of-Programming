Having all input files tested, is able to get all output right .

Run the Compiler class with sample input and sample output,the result will be printed out in the sample output.txt
abstract class Case
{
	SList sList;

	abstract void printParseTree(String indent);

	abstract void emitInstructions();

}

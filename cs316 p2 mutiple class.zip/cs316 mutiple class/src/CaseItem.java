
public class CaseItem {

}

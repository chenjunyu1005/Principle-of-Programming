import java.util.*;
abstract class Statement {
		void printParseTree(String indent)
		{
			IO.display(indent + indent.length() + " <statement>");
			indent = indent+" ";

		}

		
	}




public class Label {
	int val;

	Label(int i)
	{
		val = i;
	}

	void printParseTree(String indent)
	{
		IO.displayln(" " + val);
	}
}
import java.util.*;

abstract class TermItem
{
	Term term;

	abstract void printParseTree(String indent);
	
}
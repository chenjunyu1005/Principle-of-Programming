
public class Assign {
String id;
Expr expr;
Assign(String s,Expr exp)
{
 id=s;
 expr=exp;
}
}

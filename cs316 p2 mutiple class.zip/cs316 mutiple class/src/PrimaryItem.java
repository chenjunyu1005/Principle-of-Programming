import java.util.*;

abstract class PrimaryItem
{
	Primary primary;

	abstract void printParseTree(String indent);
	
}

public class BoolLiteral {

}
